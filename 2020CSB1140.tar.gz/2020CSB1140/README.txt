Name - Vijay Dwivedi
Roll number - 2020CSB1140

CS202 LAB 2 ( TicTacToe )

--> IMPLEMENTATION <--

--> The Game is implemented in java
--> There is a main function named as TicTacToe.
--> There are 4 more functions other than TicTacToe which are as follows :

-winner ( for checking if there is a winner for the Game )
-print ( for printing the TicTacToe board )
-ifwin ( for checking if computer can win by playing a chance )
-stopwin ( to stop the player's chance to win )


--> RULES <--

--> There are 9 places to play a chance

	1 2 3
	4 5 6
	7 8 9

--> if there is a row/comlumn /diagonal is filled with the same symbol means the player with that symbol won the game.


--> HOW TO RUN <--

--> first you have to choose 1 for player vs player Game or 2 for Computer vs player Game 
--> Then enter the player/player's name.
--> then select the appropriate postion that you want to fill with your symbol ( O or X ).


